public class Loop9056_ex연습 {
    public static void main(String[] args) {

        int a,i;

        for(a=1; a<=3; a++) {
            for (i = 1; i <= a; i++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
