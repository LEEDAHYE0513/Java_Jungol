import java.util.Scanner;

public class Loop125_ex형성 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int a;
        int b;
        a= input.nextInt();
        for (b=1; b<=a; b++){
            System.out.print(b+" ");
        }

    }

}
