public class Loop548_self1 {
    public static void main(String[] args) {
        int a,b;
        for (a=2; a<=4; a++){
            for (b = 1; b<=5; b++){
                System.out.printf("%d * %d =%3d   ",a,b,a*b);
            }
            System.out.println();
        }

    }
}
