public class Loop9048_ex연습 {
    public static void main(String[] args) {

        int a;

        for(a=0; a<=20; a++){
            if(a%2==1){
                System.out.print(a+" ");
            }
        }
    }
}
