public class Loop9047_ex연습 {
    public static void main(String[] args) {

        char a;

        for (a='A'; a<='Z'; a++){
            System.out.print(a);
        }
    }
}
