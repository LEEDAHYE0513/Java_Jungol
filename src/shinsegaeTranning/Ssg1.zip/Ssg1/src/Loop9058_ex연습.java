import java.util.Scanner;

public class Loop9058_ex연습 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int n, i, j,a;
        n = input.nextInt();


//        for (i = 1; i <= n; i++) {
//            for (j = n; j > i; j--) {
//                System.out.print(" ");
//            }
//            for (j = 1; j <= i; j++) {
//                System.out.print(++a);
//            }
//            System.out.println();
//        }
    }
}
/*
55550
55500
55000
50000
00000

 */