public class Loop547_self1 {
    public static void main(String[] args) {

        int i,j;
        for (i = 2; i<=6; i++){
            for (j=i; j<=i+4; j++){
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }
}
