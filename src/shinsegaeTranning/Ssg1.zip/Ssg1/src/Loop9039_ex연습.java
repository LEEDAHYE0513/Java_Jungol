public class Loop9039_ex연습 {
    public static void main(String[] args) {
        for (char a= 'A'; a<='Z'; a++) {
            System.out.print(a);
        }

    }
}
