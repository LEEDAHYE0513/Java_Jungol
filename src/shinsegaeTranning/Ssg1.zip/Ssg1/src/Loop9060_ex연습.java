public class  Loop9060_ex연습 {
    public static void main(String[] args) {

    }
}
