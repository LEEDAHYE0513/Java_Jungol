public class Loop536_self1자가 {
    public static void main(String[] args) {

    }
}
