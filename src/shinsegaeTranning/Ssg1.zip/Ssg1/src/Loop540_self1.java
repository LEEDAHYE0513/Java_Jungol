public class Loop540_self1 {
    public static void main(String[] args) {
        
    }
}
