public class Loop536_self1 {
    public static void main(String[] args) {

        /* for문 사용
    for (int i = 1; i<=15; i++){
            System.out.println(i);
        }
    }

         */

        /* while

         */
        int i;
        i = 0;
        while (i < 15) {
            i++;
            System.out.print(i + " ");
        }

    }
}