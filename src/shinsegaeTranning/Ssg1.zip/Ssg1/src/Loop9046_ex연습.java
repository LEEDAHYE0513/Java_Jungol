import java.util.Scanner;

public class Loop9046_ex연습 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int a;
        int i= input.nextInt();

        for (a=0; a<i; a++) {

            System.out.print("C언어 프로그래밍\n");
        }
    }
}
