import java.util.Scanner;

public class Loop541_self1 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int a;
        char i;

        i= input.next().charAt(0);
        for(a=0; a<20; a++){
            System.out.print(i);
        }

    }
}
