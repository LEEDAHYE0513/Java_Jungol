package shinsegaeTranning.javaBasic;

public class JavaBasic3 {
    public static void main(String[] args) {
        int a,b;
        a=0; b=0;
        while(true){
            if (a+b!=5){
                continue;
            }
            else {
                break;
            }
        }
    }
}
