package shinsegaeTranning.javaBasic;

public class JavaBasic8 {
    public static void main(String[] args) {

    }
}
