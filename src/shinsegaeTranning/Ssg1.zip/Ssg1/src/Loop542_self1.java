public class Loop542_self1 {
    public static void main(String[] args) {
        int i;
        for (i=10; i<=20; i++){
            System.out.print(i+" ");
        }
    }
}
