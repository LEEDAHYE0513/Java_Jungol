public class Loop633_self1 {
    public static void main(String[] args) {
        
    }
}
