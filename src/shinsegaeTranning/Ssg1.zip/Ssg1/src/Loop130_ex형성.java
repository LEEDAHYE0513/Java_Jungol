import java.util.Scanner;

public class Loop130_ex형성 {
    public static void main(String[] args) {

        Scanner input =new Scanner(System.in);

        int i,a;
        i = input.nextInt();
        for (a = 1; a<=i; a++){
            System.out.println("JUNGOL");
        }

    }
}
