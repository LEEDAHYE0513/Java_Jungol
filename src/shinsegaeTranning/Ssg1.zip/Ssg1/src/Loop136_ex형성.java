import java.util.Scanner;

public class Loop136_ex형성 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int a,i;
        a = input.nextInt();
        for(i=1; i<=10; i++){
            System.out.print(a*i +" ");
        }
    }
}
