package Array;

//연도와 월을 입력받아 해당 월의 날 수를 출력하다가
// 월이 0이면 종료하는 프로그램을 작성하시오.
// (월이 잘못 입력되면 "잘못 입력하였습니다."를 출력한다.)

import org.w3c.dom.ls.LSOutput;

import java.time.LocalDate;
import java.util.Scanner;

public class Array9069_ex연습 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

//        int YEAR = 0;
//        int MONTH = 0;
//
//        while(true){
//            YEAR = input.nextInt();
//            MONTH = input.nextInt();
//
//
//            if(MONTH==0) {
//                System.out.println("잘못_입력하였습니다");
//            }
//        }
//
//
//        System.out.println("YEAR = %d", );
//        System.out.println("YEAR = %d", );
//
//        System.out.println("입력하신 달의 날 수는 %d일입니다.", );


    }

}
