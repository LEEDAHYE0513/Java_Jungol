package shinsegaeTranning.javaBasic;

public class JavaBasic6 {
    public static void main(String[] args) {
        int i, j ;

        System.out.println();
        for (i = 1; i <= 5; i++) {
            for (j = 5; j >i-1; j--) {
                System.out.print(" ");
            }
            for (j = 1; j < i+1; j++) {
                System.out.print("*");
            }
            System.out.println();

        }
    }
}
//for (i = 1; i <= 3; i++) {
//            for (j = 3; j >= i; j--) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }