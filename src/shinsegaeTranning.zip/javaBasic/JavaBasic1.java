package shinsegaeTranning.javaBasic;

public class JavaBasic1 {
    public static void main(String[] args) {

    }
}
