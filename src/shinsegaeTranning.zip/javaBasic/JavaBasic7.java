package shinsegaeTranning.javaBasic;

public class JavaBasic7 {
    public static void main(String[] args) {
        int num = 1;

        for (int i = 1; i <= 3; i++) {
            for (int j = 4 ; j > i-1; j--) {
                System.out.print(" ");
            }
            for (int j = 1; j < num+1; j++) {
                System.out.print("@");
            } num +=2;
            System.out.println();

        }
        for(int a=1; a<=3; a++) {
            for (int i = 1; i <= a+1; i++) {
                System.out.print(" ");
            }
            for (int i = 3; i >= a; i--) {
                System.out.print("@");
            }num -=2;
            System.out.println();
        }
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= i-1; j++) {
                System.out.print("s");
            }
            for (int k=3 ; k >= i; k--) {
                System.out.print("*");
            }num-=2;
            System.out.println();
        }




    }
}
