package Array2;

public class Array9077_ex연습 {
    public static void main(String[] args) {

        int[][] a = {{3, 5, 4}, {2, 6, 7},{8, 10, 1}};
        //1차원 배열 출력
        // System.out.println(Arrays.toString(a));
        // 2차원 배열 출력
        // System.out.println(Arrays.deepToString(a));

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }


//        int []a =new int[] {3, 5, 4};
//        int []b =new int[] {2, 6, 7,};
//        int []c =new int[] {8, 10, 1};
//
//
//        for (int i = 0; i < 3; i++) {
//            System.out.print(a[i] + " ");
//        }System.out.println();
//        for (int i = 0; i < 3; i++) {
//            System.out.print(b[i]+ " ");
//
//        }System.out.println();
//        for (int i = 0; i < 3; i++) {
//            System.out.print(c[i]+ " ");
//        }System.out.println();
    }


}
